package com.zosh;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GdsSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(GdsSystemApplication.class, args);
	}

}
